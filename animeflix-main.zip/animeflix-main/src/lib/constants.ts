export const aniListEndpoint = 'https://graphql.anilist.co';
export const kitsuEndpoint = 'https://kitsu.io/api/graphql';

export const proxyFreeUrls = /(gogocdn\.stream)|(manifest\.prod\.boltdns\.net)/;
